var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "28000",
        "ok": "28000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "25008",
        "ok": "25008",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1094",
        "ok": "1094",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2515",
        "ok": "2515",
        "ko": "-"
    },
    "percentiles1": {
        "total": "16",
        "ok": "16",
        "ko": "-"
    },
    "percentiles2": {
        "total": "755",
        "ok": "755",
        "ko": "-"
    },
    "percentiles3": {
        "total": "6751",
        "ok": "6751",
        "ko": "-"
    },
    "percentiles4": {
        "total": "12881",
        "ok": "12881",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 21110,
        "percentage": 75
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 958,
        "percentage": 3
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 5932,
        "percentage": 21
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "129.032",
        "ok": "129.032",
        "ko": "-"
    }
},
contents: {
"req_request-0-684d2": {
        type: "REQUEST",
        name: "request_0",
path: "request_0",
pathFormatted: "req_request-0-684d2",
stats: {
    "name": "request_0",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "59",
        "ok": "59",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "percentiles2": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "percentiles4": {
        "total": "41",
        "ok": "41",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-1-46da4": {
        type: "REQUEST",
        name: "request_1",
path: "request_1",
pathFormatted: "req_request-1-46da4",
stats: {
    "name": "request_1",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "45",
        "ok": "45",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "percentiles1": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "percentiles2": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "percentiles3": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "percentiles4": {
        "total": "22",
        "ok": "22",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-2-93baf": {
        type: "REQUEST",
        name: "request_2",
path: "request_2",
pathFormatted: "req_request-2-93baf",
stats: {
    "name": "request_2",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "59",
        "ok": "59",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "26",
        "ok": "26",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "percentiles1": {
        "total": "26",
        "ok": "26",
        "ko": "-"
    },
    "percentiles2": {
        "total": "32",
        "ok": "32",
        "ko": "-"
    },
    "percentiles3": {
        "total": "43",
        "ok": "43",
        "ko": "-"
    },
    "percentiles4": {
        "total": "52",
        "ok": "52",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-3-d0973": {
        type: "REQUEST",
        name: "request_3",
path: "request_3",
pathFormatted: "req_request-3-d0973",
stats: {
    "name": "request_3",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "71",
        "ok": "71",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "percentiles1": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles3": {
        "total": "24",
        "ok": "24",
        "ko": "-"
    },
    "percentiles4": {
        "total": "43",
        "ok": "43",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-4-e7d1b": {
        type: "REQUEST",
        name: "request_4",
path: "request_4",
pathFormatted: "req_request-4-e7d1b",
stats: {
    "name": "request_4",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "103",
        "ok": "103",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19",
        "ok": "19",
        "ko": "-"
    },
    "percentiles4": {
        "total": "53",
        "ok": "53",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-5-48829": {
        type: "REQUEST",
        name: "request_5",
path: "request_5",
pathFormatted: "req_request-5-48829",
stats: {
    "name": "request_5",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "147",
        "ok": "147",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "percentiles1": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles3": {
        "total": "22",
        "ok": "22",
        "ko": "-"
    },
    "percentiles4": {
        "total": "51",
        "ok": "51",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-6-027a9": {
        type: "REQUEST",
        name: "request_6",
path: "request_6",
pathFormatted: "req_request-6-027a9",
stats: {
    "name": "request_6",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "69",
        "ok": "69",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "percentiles3": {
        "total": "29",
        "ok": "29",
        "ko": "-"
    },
    "percentiles4": {
        "total": "61",
        "ok": "61",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-7-f222f": {
        type: "REQUEST",
        name: "request_7",
path: "request_7",
pathFormatted: "req_request-7-f222f",
stats: {
    "name": "request_7",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "42",
        "ok": "42",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "percentiles1": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16",
        "ok": "16",
        "ko": "-"
    },
    "percentiles3": {
        "total": "24",
        "ok": "24",
        "ko": "-"
    },
    "percentiles4": {
        "total": "36",
        "ok": "36",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-8-ef0c8": {
        type: "REQUEST",
        name: "request_8",
path: "request_8",
pathFormatted: "req_request-8-ef0c8",
stats: {
    "name": "request_8",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "41",
        "ok": "41",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "percentiles1": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "percentiles3": {
        "total": "22",
        "ok": "22",
        "ko": "-"
    },
    "percentiles4": {
        "total": "31",
        "ok": "31",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-9-d127e": {
        type: "REQUEST",
        name: "request_9",
path: "request_9",
pathFormatted: "req_request-9-d127e",
stats: {
    "name": "request_9",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "64",
        "ok": "64",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "percentiles1": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles3": {
        "total": "33",
        "ok": "33",
        "ko": "-"
    },
    "percentiles4": {
        "total": "45",
        "ok": "45",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-10-1cfbe": {
        type: "REQUEST",
        name: "request_10",
path: "request_10",
pathFormatted: "req_request-10-1cfbe",
stats: {
    "name": "request_10",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "795",
        "ok": "795",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16539",
        "ok": "16539",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10112",
        "ok": "10112",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4056",
        "ok": "4056",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11307",
        "ok": "11307",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13562",
        "ok": "13562",
        "ko": "-"
    },
    "percentiles3": {
        "total": "15472",
        "ok": "15472",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15731",
        "ok": "15731",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 7,
        "percentage": 1
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 492,
        "percentage": 98
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-10-redi-69a19": {
        type: "REQUEST",
        name: "request_10 Redirect 1",
path: "request_10 Redirect 1",
pathFormatted: "req_request-10-redi-69a19",
stats: {
    "name": "request_10 Redirect 1",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16835",
        "ok": "16835",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "7385",
        "ok": "7385",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3778",
        "ok": "3778",
        "ko": "-"
    },
    "percentiles1": {
        "total": "7647",
        "ok": "7647",
        "ko": "-"
    },
    "percentiles2": {
        "total": "9661",
        "ok": "9661",
        "ko": "-"
    },
    "percentiles3": {
        "total": "13172",
        "ok": "13172",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15304",
        "ok": "15304",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 31,
        "percentage": 6
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 4,
        "percentage": 1
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 465,
        "percentage": 93
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-11-f11e8": {
        type: "REQUEST",
        name: "request_11",
path: "request_11",
pathFormatted: "req_request-11-f11e8",
stats: {
    "name": "request_11",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "12428",
        "ok": "12428",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2147",
        "ok": "2147",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2769",
        "ok": "2769",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1430",
        "ok": "1430",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2088",
        "ok": "2088",
        "ko": "-"
    },
    "percentiles3": {
        "total": "9248",
        "ok": "9248",
        "ko": "-"
    },
    "percentiles4": {
        "total": "10278",
        "ok": "10278",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 181,
        "percentage": 36
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 15,
        "percentage": 3
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 304,
        "percentage": 61
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-12-61da2": {
        type: "REQUEST",
        name: "request_12",
path: "request_12",
pathFormatted: "req_request-12-61da2",
stats: {
    "name": "request_12",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "11418",
        "ok": "11418",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "887",
        "ok": "887",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1580",
        "ok": "1580",
        "ko": "-"
    },
    "percentiles1": {
        "total": "663",
        "ok": "663",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1138",
        "ok": "1138",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3047",
        "ok": "3047",
        "ko": "-"
    },
    "percentiles4": {
        "total": "9646",
        "ok": "9646",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 332,
        "percentage": 66
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 61,
        "percentage": 12
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 107,
        "percentage": 21
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-13-5cca6": {
        type: "REQUEST",
        name: "request_13",
path: "request_13",
pathFormatted: "req_request-13-5cca6",
stats: {
    "name": "request_13",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "10402",
        "ok": "10402",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "705",
        "ok": "705",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1011",
        "ok": "1011",
        "ko": "-"
    },
    "percentiles1": {
        "total": "608",
        "ok": "608",
        "ko": "-"
    },
    "percentiles2": {
        "total": "972",
        "ok": "973",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1870",
        "ok": "1870",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4186",
        "ok": "4186",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 348,
        "percentage": 70
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 57,
        "percentage": 11
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 95,
        "percentage": 19
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-14-a0e30": {
        type: "REQUEST",
        name: "request_14",
path: "request_14",
pathFormatted: "req_request-14-a0e30",
stats: {
    "name": "request_14",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "12054",
        "ok": "12054",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "588",
        "ok": "588",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1001",
        "ok": "1001",
        "ko": "-"
    },
    "percentiles1": {
        "total": "576",
        "ok": "576",
        "ko": "-"
    },
    "percentiles2": {
        "total": "767",
        "ok": "767",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1462",
        "ok": "1462",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3128",
        "ok": "3128",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 394,
        "percentage": 79
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 58,
        "percentage": 12
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 48,
        "percentage": 10
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-15-56eac": {
        type: "REQUEST",
        name: "request_15",
path: "request_15",
pathFormatted: "req_request-15-56eac",
stats: {
    "name": "request_15",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "106",
        "ok": "106",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles1": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16",
        "ok": "16",
        "ko": "-"
    },
    "percentiles3": {
        "total": "33",
        "ok": "33",
        "ko": "-"
    },
    "percentiles4": {
        "total": "76",
        "ok": "76",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-16-24733": {
        type: "REQUEST",
        name: "request_16",
path: "request_16",
pathFormatted: "req_request-16-24733",
stats: {
    "name": "request_16",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "188",
        "ok": "188",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "percentiles1": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "percentiles2": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "percentiles3": {
        "total": "33",
        "ok": "33",
        "ko": "-"
    },
    "percentiles4": {
        "total": "66",
        "ok": "66",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-17-cd6a2": {
        type: "REQUEST",
        name: "request_17",
path: "request_17",
pathFormatted: "req_request-17-cd6a2",
stats: {
    "name": "request_17",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "9209",
        "ok": "9209",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "267",
        "ok": "267",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "536",
        "ok": "536",
        "ko": "-"
    },
    "percentiles1": {
        "total": "71",
        "ok": "71",
        "ko": "-"
    },
    "percentiles2": {
        "total": "311",
        "ok": "311",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1005",
        "ok": "1005",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1381",
        "ok": "1381",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 448,
        "percentage": 90
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 43,
        "percentage": 9
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 9,
        "percentage": 2
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-18-f5b64": {
        type: "REQUEST",
        name: "request_18",
path: "request_18",
pathFormatted: "req_request-18-f5b64",
stats: {
    "name": "request_18",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2042",
        "ok": "2042",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "366",
        "ok": "366",
        "ko": "-"
    },
    "percentiles1": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles2": {
        "total": "150",
        "ok": "150",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1179",
        "ok": "1179",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1316",
        "ok": "1316",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 443,
        "percentage": 89
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 43,
        "percentage": 9
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 14,
        "percentage": 3
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-19-10d85": {
        type: "REQUEST",
        name: "request_19",
path: "request_19",
pathFormatted: "req_request-19-10d85",
stats: {
    "name": "request_19",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "253",
        "ok": "253",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "27",
        "ok": "27",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "43",
        "ok": "43",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "percentiles2": {
        "total": "24",
        "ok": "24",
        "ko": "-"
    },
    "percentiles3": {
        "total": "56",
        "ok": "56",
        "ko": "-"
    },
    "percentiles4": {
        "total": "252",
        "ok": "252",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-20-6804b": {
        type: "REQUEST",
        name: "request_20",
path: "request_20",
pathFormatted: "req_request-20-6804b",
stats: {
    "name": "request_20",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "294",
        "ok": "294",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "21",
        "ok": "21",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "26",
        "ok": "26",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "percentiles2": {
        "total": "22",
        "ok": "22",
        "ko": "-"
    },
    "percentiles3": {
        "total": "49",
        "ok": "49",
        "ko": "-"
    },
    "percentiles4": {
        "total": "89",
        "ok": "89",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-21-be4cb": {
        type: "REQUEST",
        name: "request_21",
path: "request_21",
pathFormatted: "req_request-21-be4cb",
stats: {
    "name": "request_21",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "39",
        "ok": "39",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "11823",
        "ok": "11823",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3947",
        "ok": "3947",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2997",
        "ok": "2997",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3451",
        "ok": "3451",
        "ko": "-"
    },
    "percentiles2": {
        "total": "6176",
        "ok": "6176",
        "ko": "-"
    },
    "percentiles3": {
        "total": "9357",
        "ok": "9357",
        "ko": "-"
    },
    "percentiles4": {
        "total": "10298",
        "ok": "10298",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 93,
        "percentage": 19
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 37,
        "percentage": 7
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 370,
        "percentage": 74
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-22-8ecb1": {
        type: "REQUEST",
        name: "request_22",
path: "request_22",
pathFormatted: "req_request-22-8ecb1",
stats: {
    "name": "request_22",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1389",
        "ok": "1389",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "288",
        "ok": "288",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "409",
        "ok": "409",
        "ko": "-"
    },
    "percentiles1": {
        "total": "22",
        "ok": "22",
        "ko": "-"
    },
    "percentiles2": {
        "total": "507",
        "ok": "507",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1138",
        "ok": "1138",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1331",
        "ok": "1331",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 401,
        "percentage": 80
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 84,
        "percentage": 17
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 15,
        "percentage": 3
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-23-98f5d": {
        type: "REQUEST",
        name: "request_23",
path: "request_23",
pathFormatted: "req_request-23-98f5d",
stats: {
    "name": "request_23",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "75",
        "ok": "75",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "percentiles1": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16",
        "ok": "16",
        "ko": "-"
    },
    "percentiles3": {
        "total": "32",
        "ok": "32",
        "ko": "-"
    },
    "percentiles4": {
        "total": "49",
        "ok": "49",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-24-dd0c9": {
        type: "REQUEST",
        name: "request_24",
path: "request_24",
pathFormatted: "req_request-24-dd0c9",
stats: {
    "name": "request_24",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "253",
        "ok": "253",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "17",
        "ok": "17",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    },
    "percentiles2": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "percentiles3": {
        "total": "31",
        "ok": "31",
        "ko": "-"
    },
    "percentiles4": {
        "total": "54",
        "ok": "54",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-25-20ee6": {
        type: "REQUEST",
        name: "request_25",
path: "request_25",
pathFormatted: "req_request-25-20ee6",
stats: {
    "name": "request_25",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1332",
        "ok": "1332",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "169",
        "ok": "169",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "322",
        "ok": "322",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "percentiles2": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1049",
        "ok": "1049",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1232",
        "ok": "1232",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 452,
        "percentage": 90
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 41,
        "percentage": 8
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 7,
        "percentage": 1
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-25-redi-fc2a1": {
        type: "REQUEST",
        name: "request_25 Redirect 1",
path: "request_25 Redirect 1",
pathFormatted: "req_request-25-redi-fc2a1",
stats: {
    "name": "request_25 Redirect 1",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1960",
        "ok": "1960",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "354",
        "ok": "354",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "508",
        "ok": "508",
        "ko": "-"
    },
    "percentiles1": {
        "total": "51",
        "ok": "51",
        "ko": "-"
    },
    "percentiles2": {
        "total": "514",
        "ok": "514",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1454",
        "ok": "1454",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1691",
        "ok": "1691",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 408,
        "percentage": 82
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 20,
        "percentage": 4
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 72,
        "percentage": 14
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-26-18b3c": {
        type: "REQUEST",
        name: "request_26",
path: "request_26",
pathFormatted: "req_request-26-18b3c",
stats: {
    "name": "request_26",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "138",
        "ok": "138",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "9827",
        "ok": "9827",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "5297",
        "ok": "5297",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2018",
        "ok": "2018",
        "ko": "-"
    },
    "percentiles1": {
        "total": "5614",
        "ok": "5614",
        "ko": "-"
    },
    "percentiles2": {
        "total": "6583",
        "ok": "6583",
        "ko": "-"
    },
    "percentiles3": {
        "total": "8204",
        "ok": "8204",
        "ko": "-"
    },
    "percentiles4": {
        "total": "9083",
        "ok": "9083",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 20,
        "percentage": 4
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 9,
        "percentage": 2
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 471,
        "percentage": 94
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-26-redi-0a71d": {
        type: "REQUEST",
        name: "request_26 Redirect 1",
path: "request_26 Redirect 1",
pathFormatted: "req_request-26-redi-0a71d",
stats: {
    "name": "request_26 Redirect 1",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "9739",
        "ok": "9739",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3257",
        "ok": "3257",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2508",
        "ok": "2508",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2720",
        "ok": "2720",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5213",
        "ok": "5213",
        "ko": "-"
    },
    "percentiles3": {
        "total": "7575",
        "ok": "7575",
        "ko": "-"
    },
    "percentiles4": {
        "total": "9163",
        "ok": "9163",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 123,
        "percentage": 25
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 6,
        "percentage": 1
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 371,
        "percentage": 74
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-27-649b0": {
        type: "REQUEST",
        name: "request_27",
path: "request_27",
pathFormatted: "req_request-27-649b0",
stats: {
    "name": "request_27",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4680",
        "ok": "4680",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1177",
        "ok": "1177",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1326",
        "ok": "1326",
        "ko": "-"
    },
    "percentiles1": {
        "total": "847",
        "ok": "847",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1529",
        "ok": "1529",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3760",
        "ok": "3760",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4399",
        "ok": "4399",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 227,
        "percentage": 45
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 57,
        "percentage": 11
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 216,
        "percentage": 43
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-28-297b8": {
        type: "REQUEST",
        name: "request_28",
path: "request_28",
pathFormatted: "req_request-28-297b8",
stats: {
    "name": "request_28",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "102",
        "ok": "102",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    },
    "percentiles2": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "percentiles3": {
        "total": "28",
        "ok": "28",
        "ko": "-"
    },
    "percentiles4": {
        "total": "50",
        "ok": "50",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-29-6a22e": {
        type: "REQUEST",
        name: "request_29",
path: "request_29",
pathFormatted: "req_request-29-6a22e",
stats: {
    "name": "request_29",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "155",
        "ok": "155",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "percentiles1": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "percentiles2": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "percentiles3": {
        "total": "28",
        "ok": "28",
        "ko": "-"
    },
    "percentiles4": {
        "total": "40",
        "ok": "40",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-30-b7b42": {
        type: "REQUEST",
        name: "request_30",
path: "request_30",
pathFormatted: "req_request-30-b7b42",
stats: {
    "name": "request_30",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6562",
        "ok": "6562",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "912",
        "ok": "912",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1396",
        "ok": "1396",
        "ko": "-"
    },
    "percentiles1": {
        "total": "202",
        "ok": "202",
        "ko": "-"
    },
    "percentiles2": {
        "total": "979",
        "ok": "979",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4660",
        "ok": "4660",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5803",
        "ok": "5803",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 357,
        "percentage": 71
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 23,
        "percentage": 5
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 120,
        "percentage": 24
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-31-261d3": {
        type: "REQUEST",
        name: "request_31",
path: "request_31",
pathFormatted: "req_request-31-261d3",
stats: {
    "name": "request_31",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5774",
        "ok": "5774",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "532",
        "ok": "532",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "988",
        "ok": "988",
        "ko": "-"
    },
    "percentiles1": {
        "total": "18",
        "ok": "18",
        "ko": "-"
    },
    "percentiles2": {
        "total": "707",
        "ok": "707",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2679",
        "ok": "2679",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4052",
        "ok": "4052",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 380,
        "percentage": 76
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 39,
        "percentage": 8
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 81,
        "percentage": 16
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-32-84a21": {
        type: "REQUEST",
        name: "request_32",
path: "request_32",
pathFormatted: "req_request-32-84a21",
stats: {
    "name": "request_32",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "64",
        "ok": "64",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "percentiles1": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16",
        "ok": "16",
        "ko": "-"
    },
    "percentiles3": {
        "total": "30",
        "ok": "30",
        "ko": "-"
    },
    "percentiles4": {
        "total": "48",
        "ok": "48",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-33-6bb92": {
        type: "REQUEST",
        name: "request_33",
path: "request_33",
pathFormatted: "req_request-33-6bb92",
stats: {
    "name": "request_33",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "47",
        "ok": "47",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "percentiles1": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "percentiles2": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "percentiles3": {
        "total": "24",
        "ok": "24",
        "ko": "-"
    },
    "percentiles4": {
        "total": "42",
        "ok": "42",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-34-d9757": {
        type: "REQUEST",
        name: "request_34",
path: "request_34",
pathFormatted: "req_request-34-d9757",
stats: {
    "name": "request_34",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "175",
        "ok": "175",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "25008",
        "ok": "25008",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "5634",
        "ok": "5634",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4006",
        "ok": "4006",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4069",
        "ok": "4069",
        "ko": "-"
    },
    "percentiles2": {
        "total": "8112",
        "ok": "8112",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14065",
        "ok": "14065",
        "ko": "-"
    },
    "percentiles4": {
        "total": "17421",
        "ok": "17421",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 12,
        "percentage": 2
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 6,
        "percentage": 1
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 482,
        "percentage": 96
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-35-3745a": {
        type: "REQUEST",
        name: "request_35",
path: "request_35",
pathFormatted: "req_request-35-3745a",
stats: {
    "name": "request_35",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3194",
        "ok": "3194",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "617",
        "ok": "617",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "735",
        "ok": "735",
        "ko": "-"
    },
    "percentiles1": {
        "total": "118",
        "ok": "118",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1273",
        "ok": "1273",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1928",
        "ok": "1928",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2265",
        "ok": "2265",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 324,
        "percentage": 65
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 39,
        "percentage": 8
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 137,
        "percentage": 27
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-36-9ad97": {
        type: "REQUEST",
        name: "request_36",
path: "request_36",
pathFormatted: "req_request-36-9ad97",
stats: {
    "name": "request_36",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "63",
        "ok": "63",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "percentiles1": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles2": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "percentiles3": {
        "total": "28",
        "ok": "28",
        "ko": "-"
    },
    "percentiles4": {
        "total": "38",
        "ok": "38",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-37-6b2c3": {
        type: "REQUEST",
        name: "request_37",
path: "request_37",
pathFormatted: "req_request-37-6b2c3",
stats: {
    "name": "request_37",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "45",
        "ok": "45",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "percentiles1": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "percentiles2": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "percentiles3": {
        "total": "24",
        "ok": "24",
        "ko": "-"
    },
    "percentiles4": {
        "total": "41",
        "ok": "41",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-38-ab13e": {
        type: "REQUEST",
        name: "request_38",
path: "request_38",
pathFormatted: "req_request-38-ab13e",
stats: {
    "name": "request_38",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2521",
        "ok": "2521",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "653",
        "ok": "653",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "713",
        "ok": "713",
        "ko": "-"
    },
    "percentiles1": {
        "total": "192",
        "ok": "192",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1302",
        "ok": "1302",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1842",
        "ok": "1842",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2082",
        "ok": "2082",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 277,
        "percentage": 55
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 91,
        "percentage": 18
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 132,
        "percentage": 26
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-38-redi-2af86": {
        type: "REQUEST",
        name: "request_38 Redirect 1",
path: "request_38 Redirect 1",
pathFormatted: "req_request-38-redi-2af86",
stats: {
    "name": "request_38 Redirect 1",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6172",
        "ok": "6172",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "824",
        "ok": "824",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1134",
        "ok": "1134",
        "ko": "-"
    },
    "percentiles1": {
        "total": "168",
        "ok": "168",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1459",
        "ok": "1459",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3665",
        "ok": "3665",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4172",
        "ok": "4172",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 308,
        "percentage": 62
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 19,
        "percentage": 4
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 173,
        "percentage": 35
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-39-bb0c9": {
        type: "REQUEST",
        name: "request_39",
path: "request_39",
pathFormatted: "req_request-39-bb0c9",
stats: {
    "name": "request_39",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "804",
        "ok": "804",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "18203",
        "ok": "18203",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "5308",
        "ok": "5308",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2786",
        "ok": "2786",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4538",
        "ok": "4538",
        "ko": "-"
    },
    "percentiles2": {
        "total": "6492",
        "ok": "6492",
        "ko": "-"
    },
    "percentiles3": {
        "total": "11587",
        "ok": "11587",
        "ko": "-"
    },
    "percentiles4": {
        "total": "14180",
        "ok": "14180",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 3,
        "percentage": 1
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 497,
        "percentage": 99
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-39-redi-8619b": {
        type: "REQUEST",
        name: "request_39 Redirect 1",
path: "request_39 Redirect 1",
pathFormatted: "req_request-39-redi-8619b",
stats: {
    "name": "request_39 Redirect 1",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "37",
        "ok": "37",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16394",
        "ok": "16394",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3790",
        "ok": "3790",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2363",
        "ok": "2363",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3294",
        "ok": "3294",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5058",
        "ok": "5058",
        "ko": "-"
    },
    "percentiles3": {
        "total": "8339",
        "ok": "8339",
        "ko": "-"
    },
    "percentiles4": {
        "total": "11471",
        "ok": "11471",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 13,
        "percentage": 3
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 24,
        "percentage": 5
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 463,
        "percentage": 93
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-40-3bad7": {
        type: "REQUEST",
        name: "request_40",
path: "request_40",
pathFormatted: "req_request-40-3bad7",
stats: {
    "name": "request_40",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3405",
        "ok": "3405",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "677",
        "ok": "677",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "745",
        "ok": "745",
        "ko": "-"
    },
    "percentiles1": {
        "total": "418",
        "ok": "418",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1178",
        "ok": "1178",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2001",
        "ok": "2001",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2612",
        "ok": "2612",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 330,
        "percentage": 66
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 46,
        "percentage": 9
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 124,
        "percentage": 25
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-41-12d9b": {
        type: "REQUEST",
        name: "request_41",
path: "request_41",
pathFormatted: "req_request-41-12d9b",
stats: {
    "name": "request_41",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "540",
        "ok": "540",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "34",
        "ok": "34",
        "ko": "-"
    },
    "percentiles1": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "percentiles2": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "percentiles3": {
        "total": "26",
        "ok": "26",
        "ko": "-"
    },
    "percentiles4": {
        "total": "44",
        "ok": "44",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-42-f6be0": {
        type: "REQUEST",
        name: "request_42",
path: "request_42",
pathFormatted: "req_request-42-f6be0",
stats: {
    "name": "request_42",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "544",
        "ok": "544",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "16",
        "ok": "16",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "41",
        "ok": "41",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    },
    "percentiles2": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "percentiles3": {
        "total": "25",
        "ok": "25",
        "ko": "-"
    },
    "percentiles4": {
        "total": "40",
        "ok": "40",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-43-a95c1": {
        type: "REQUEST",
        name: "request_43",
path: "request_43",
pathFormatted: "req_request-43-a95c1",
stats: {
    "name": "request_43",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "14661",
        "ok": "14661",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "704",
        "ok": "704",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1032",
        "ok": "1032",
        "ko": "-"
    },
    "percentiles1": {
        "total": "286",
        "ok": "286",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1165",
        "ok": "1165",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2415",
        "ok": "2415",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3082",
        "ok": "3082",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 333,
        "percentage": 67
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 45,
        "percentage": 9
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 122,
        "percentage": 24
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-44-7d234": {
        type: "REQUEST",
        name: "request_44",
path: "request_44",
pathFormatted: "req_request-44-7d234",
stats: {
    "name": "request_44",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3418",
        "ok": "3418",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "513",
        "ok": "513",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "776",
        "ok": "776",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1101",
        "ok": "1101",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1914",
        "ok": "1914",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2644",
        "ok": "2644",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 369,
        "percentage": 74
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 11,
        "percentage": 2
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 120,
        "percentage": 24
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-45-1d986": {
        type: "REQUEST",
        name: "request_45",
path: "request_45",
pathFormatted: "req_request-45-1d986",
stats: {
    "name": "request_45",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "58",
        "ok": "58",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "percentiles1": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16",
        "ok": "16",
        "ko": "-"
    },
    "percentiles3": {
        "total": "27",
        "ok": "27",
        "ko": "-"
    },
    "percentiles4": {
        "total": "45",
        "ok": "45",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-46-809be": {
        type: "REQUEST",
        name: "request_46",
path: "request_46",
pathFormatted: "req_request-46-809be",
stats: {
    "name": "request_46",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "56",
        "ok": "56",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    },
    "percentiles2": {
        "total": "17",
        "ok": "17",
        "ko": "-"
    },
    "percentiles3": {
        "total": "31",
        "ok": "31",
        "ko": "-"
    },
    "percentiles4": {
        "total": "55",
        "ok": "55",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-47-f8703": {
        type: "REQUEST",
        name: "request_47",
path: "request_47",
pathFormatted: "req_request-47-f8703",
stats: {
    "name": "request_47",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "51",
        "ok": "51",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19420",
        "ok": "19420",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3590",
        "ok": "3590",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2965",
        "ok": "2965",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3407",
        "ok": "3407",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5158",
        "ok": "5158",
        "ko": "-"
    },
    "percentiles3": {
        "total": "9496",
        "ok": "9496",
        "ko": "-"
    },
    "percentiles4": {
        "total": "11931",
        "ok": "11931",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 85,
        "percentage": 17
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 53,
        "percentage": 11
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 362,
        "percentage": 72
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-48-b3bc8": {
        type: "REQUEST",
        name: "request_48",
path: "request_48",
pathFormatted: "req_request-48-b3bc8",
stats: {
    "name": "request_48",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3155",
        "ok": "3155",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "337",
        "ok": "337",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "665",
        "ok": "665",
        "ko": "-"
    },
    "percentiles1": {
        "total": "16",
        "ok": "16",
        "ko": "-"
    },
    "percentiles2": {
        "total": "182",
        "ok": "182",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1869",
        "ok": "1869",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2781",
        "ok": "2781",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 420,
        "percentage": 84
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 17,
        "percentage": 3
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 63,
        "percentage": 13
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-49-5406f": {
        type: "REQUEST",
        name: "request_49",
path: "request_49",
pathFormatted: "req_request-49-5406f",
stats: {
    "name": "request_49",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "540",
        "ok": "540",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "24",
        "ok": "24",
        "ko": "-"
    },
    "percentiles1": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "percentiles2": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "percentiles3": {
        "total": "25",
        "ok": "25",
        "ko": "-"
    },
    "percentiles4": {
        "total": "45",
        "ok": "45",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    },"req_request-50-b37d9": {
        type: "REQUEST",
        name: "request_50",
path: "request_50",
pathFormatted: "req_request-50-b37d9",
stats: {
    "name": "request_50",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "528",
        "ok": "528",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "33",
        "ok": "33",
        "ko": "-"
    },
    "percentiles1": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "percentiles2": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "percentiles3": {
        "total": "24",
        "ok": "24",
        "ko": "-"
    },
    "percentiles4": {
        "total": "42",
        "ok": "42",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 500,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.304",
        "ok": "2.304",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
